# Cómo Agregar Imágenes a los Proyectos

## Estructura de Carpetas

Las imágenes se organizan por proyecto en:
```
src/assets/images/projects/
├── urban-tower/
├── park-mansion/
├── park-le-jade/
├── infinite-space/
├── minimal-house/
├── cube-residence/
├── glass-pavilion/
└── silence-kawana/
```

## Pasos para Agregar Imágenes

### 1. Colocar las Imágenes
Coloca tus imágenes en la carpeta correspondiente al proyecto:
- `hero.jpg` - Imagen principal/héroe del proyecto
- `image-1.jpg`, `image-2.jpg`, etc. - Imágenes adicionales

### 2. Formatos Soportados
- `.jpg` / `.jpeg`
- `.png`
- `.webp`

### 3. Modificar el Archivo del Proyecto
En el archivo del proyecto (ejemplo: `src/pages/projects/UrbanTower.tsx`):

```typescript
// Importar las imágenes
import heroImage from '@/assets/images/projects/urban-tower/hero.jpg';
import image1 from '@/assets/images/projects/urban-tower/image-1.jpg';
import image2 from '@/assets/images/projects/urban-tower/image-2.jpg';
// Importar más imágenes según necesites

const UrbanTower = () => {
  const images = [
    heroImage,
    image1,
    image2,
    // Agregar más imágenes aquí
  ];
  
  // ... resto del código
};
```

### 4. Recomendaciones
- **Resolución recomendada**: 1920x1080 o superior
- **Formato preferido**: .jpg para fotografías, .png para imágenes con transparencia
- **Tamaño de archivo**: Optimizar para web (< 2MB por imagen)
- **Nombrado**: Usar nombres descriptivos y consistentes

### 5. Ejemplo Completo
Si tienes un nuevo proyecto llamado "Modern Villa":

1. Crear carpeta: `src/assets/images/projects/modern-villa/`
2. Agregar imágenes: `hero.jpg`, `image-1.jpg`, `image-2.jpg`
3. En `src/pages/projects/ModernVilla.tsx`:

```typescript
import { ProjectPage } from '@/components/ProjectPage';
import heroImage from '@/assets/images/projects/modern-villa/hero.jpg';
import image1 from '@/assets/images/projects/modern-villa/image-1.jpg';
import image2 from '@/assets/images/projects/modern-villa/image-2.jpg';

const ModernVilla = () => {
  const images = [
    heroImage,
    image1,
    image2,
  ];

  return (
    <ProjectPage
      title="MODERN VILLA"
      subtitle="Contemporary Design"
      images={images}
      videos={[]}
    />
  );
};

export default ModernVilla;
```

## Notas Importantes
- Las imágenes se importan como ES6 modules, esto las optimiza automáticamente
- Vite se encarga del bundling y optimización
- Las rutas usan el alias `@/` que apunta a `src/`