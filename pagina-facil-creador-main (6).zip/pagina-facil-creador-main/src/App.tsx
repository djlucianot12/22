
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ParkMansion from "./pages/projects/ParkMansion";
import SilenceKawana from "./pages/projects/SilenceKawana";
import ParkLeJade from "./pages/projects/ParkLeJade";
import UrbanTower from "./pages/projects/UrbanTower";
import GlassPavilion from "./pages/projects/GlassPavilion";
import MinimalHouse from "./pages/projects/MinimalHouse";
import CubeResidence from "./pages/projects/CubeResidence";
import InfiniteSpace from "./pages/projects/InfiniteSpace";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/projects/park-mansion" element={<ParkMansion />} />
          <Route path="/projects/silence-kawana" element={<SilenceKawana />} />
          <Route path="/projects/park-le-jade" element={<ParkLeJade />} />
          <Route path="/projects/urban-tower" element={<UrbanTower />} />
          <Route path="/projects/glass-pavilion" element={<GlassPavilion />} />
          <Route path="/projects/minimal-house" element={<MinimalHouse />} />
          <Route path="/projects/cube-residence" element={<CubeResidence />} />
          <Route path="/projects/infinite-space" element={<InfiniteSpace />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
