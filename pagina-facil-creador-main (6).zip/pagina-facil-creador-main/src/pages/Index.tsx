
import { useState, useEffect } from "react";
import Intro from "@/components/Intro";
import { LiquidGlassCircle } from "@/components/LiquidGlassCircle";
import { CustomCursor } from "@/components/CustomCursor";

const Index = () => {
  const [showIntro, setShowIntro] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);
  const [showMain, setShowMain] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [showTransitionOverlay, setShowTransitionOverlay] = useState(false);

  console.log('Index component mounted', { showIntro, isLoaded, showMain, isTransitioning });

  useEffect(() => {
    console.log('Starting image preloading...');
    // Precargar imágenes
    const images = [
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1920&h=1080&fit=crop&crop=center",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1920&h=1080&fit=crop&crop=center",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1920&h=1080&fit=crop&crop=center",
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1920&h=1080&fit=crop&crop=center",
      "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=1920&h=1080&fit=crop&crop=center",
      "https://images.unsplash.com/photo-1448630360428-65456885c650?w=1920&h=1080&fit=crop&crop=center",
      "https://images.unsplash.com/photo-1494526585095-c41746248156?w=1920&h=1080&fit=crop&crop=center",
      "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=1920&h=1080&fit=crop&crop=center"
    ];

    Promise.all(
      images.map(src => {
        return new Promise((resolve) => {
          const img = new Image();
          img.onload = resolve;
          img.onerror = resolve;
          img.src = src;
        });
      })
    ).then(() => {
      console.log('Images preloaded successfully');
      setIsLoaded(true);
    });
  }, []);

  const handleIntroComplete = () => {
    if (isTransitioning) return;
    
    console.log('Intro completed, starting immersive transition');
    setIsTransitioning(true);
    
    // Transición inmersiva con efectos múltiples
    setTimeout(() => {
      setShowMain(true);
    }, 300);
    
    setTimeout(() => {
      setShowIntro(false);
      setIsTransitioning(false);
    }, 1200);
  };

  return (
    <div className="relative min-h-screen bg-black font-light overflow-hidden">
      <CustomCursor />
      
      {/* Efecto de partículas de transición */}
      {isTransitioning && (
        <div className="absolute inset-0 z-30">
          <div className="absolute inset-0 bg-gradient-radial from-transparent via-blue-500/5 to-transparent animate-pulse"></div>
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white/60 rounded-full animate-ping"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${1 + Math.random()}s`
              }}
            />
          ))}
        </div>
      )}
      
      {/* Página principal */}
      <div className={`absolute inset-0 transition-all duration-1200 ease-out ${
        showMain 
          ? 'opacity-100 scale-100 blur-0' 
          : 'opacity-0 scale-110 blur-sm'
      }`}>
        <LiquidGlassCircle />
      </div>
      
      {/* Intro */}
      {showIntro && (
        <div className={`absolute inset-0 z-50 transition-all duration-1200 ease-out ${
          isTransitioning 
            ? 'opacity-0 scale-90 blur-md' 
            : 'opacity-100 scale-100 blur-0'
        }`}>
          <Intro onComplete={handleIntroComplete} isTransitioning={isTransitioning} />
        </div>
      )}
    </div>
  );
};

export default Index;
