
import { ProjectPage } from '@/components/ProjectPage';
// Import local images
import heroImage from '@/assets/images/projects/park-mansion/hero.jpg';
import image1 from '@/assets/images/projects/park-mansion/image-1.jpg';
import image2 from '@/assets/images/projects/park-mansion/image-2.jpg';

const ParkMansion = () => {
  // Use local images, with fallback to Unsplash URLs if needed
  const images = [
    heroImage,
    image1,
    image2,
    // Fallback images if you need more
    "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=1920&h=1080&fit=crop&crop=center",
    "https://images.unsplash.com/photo-1448630360428-65456885c650?w=1920&h=1080&fit=crop&crop=center",
    "https://images.unsplash.com/photo-1494526585095-c41746248156?w=1920&h=1080&fit=crop&crop=center",
    "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=1920&h=1080&fit=crop&crop=center",
    "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1920&h=1080&fit=crop&crop=center"
  ];

  const videos = [
    "https://www.w3schools.com/html/mov_bbb.mp4",
    "https://www.w3schools.com/html/movie.mp4"
  ];

  return (
    <ProjectPage
      title="PARK MANSION"
      subtitle="Minami Azabu"
      images={images}
      videos={videos}
    />
  );
};

export default ParkMansion;
