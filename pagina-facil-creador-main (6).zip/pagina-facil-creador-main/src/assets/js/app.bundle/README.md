
# Carpeta App Bundle

Esta carpeta contiene el código JavaScript principal de tu aplicación.

Puedes incluir archivos como:
- main.js (archivo principal)
- components.js (componentes de la aplicación)
- utils.js (utilidades)
- etc.
