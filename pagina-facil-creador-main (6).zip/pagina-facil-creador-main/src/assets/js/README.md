
# Carpeta JavaScript

Esta carpeta está lista para recibir tus archivos JavaScript.

Puedes crear archivos como:
- scripts.js (JavaScript principal)
- animations.js (animaciones)
- interactions.js (interacciones)
- etc.

