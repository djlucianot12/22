
# Carpeta Vendor Bundle

Esta carpeta contiene las librerías y dependencias externas.

Puedes incluir archivos como:
- libraries.js (librerías externas)
- plugins.js (plugins de terceros)
- frameworks.js (frameworks externos)
- etc.
