
# Carpeta CSS

Esta carpeta está lista para recibir tus archivos CSS.

Puedes crear archivos como:
- styles.css (estilos principales)
- components.css (estilos de componentes)
- responsive.css (estilos responsive)
- etc.

