# Glass Pavilion - Project Images

Place images for the Glass Pavilion project in this folder.

Supported formats: .jpg, .jpeg, .png, .webp

Recommended naming:
- hero.jpg (main/hero image)
- image-1.jpg, image-2.jpg, etc. (additional images)