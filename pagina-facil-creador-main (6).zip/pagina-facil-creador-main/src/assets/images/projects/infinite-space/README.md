# Infinite Space - Project Images

Place images for the Infinite Space project in this folder.

Supported formats: .jpg, .jpeg, .png, .webp

Recommended naming:
- hero.jpg (main/hero image)
- image-1.jpg, image-2.jpg, etc. (additional images)