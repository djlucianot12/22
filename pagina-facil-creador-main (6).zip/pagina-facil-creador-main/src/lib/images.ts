// Helper function to load project images dynamically
export const loadProjectImages = async (projectName: string): Promise<string[]> => {
  const images: string[] = [];
  
  try {
    // Try to load hero image
    const heroImage = await import(`@/assets/images/projects/${projectName}/hero.jpg`);
    images.push(heroImage.default);
  } catch (error) {
    console.warn(`Hero image not found for ${projectName}`);
  }
  
  // Try to load additional images (up to 10)
  for (let i = 1; i <= 10; i++) {
    try {
      const image = await import(`@/assets/images/projects/${projectName}/image-${i}.jpg`);
      images.push(image.default);
    } catch (error) {
      // Stop when no more images are found
      break;
    }
  }
  
  return images;
};

// Get project images with fallback to Unsplash URLs
export const getProjectImages = (projectName: string, fallbackImages: string[] = []): string[] => {
  // For now, return the fallback images
  // In production, you'd load from the local images folder
  return fallbackImages;
};