
const Loading = () => {
  return (
    <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
      <div className="text-center">
        <div className="relative">
          <div className="w-16 h-16 border-4 border-gray-200 border-t-gray-900 rounded-full animate-spin mb-4"></div>
        </div>
        <div className="text-2xl font-bold tracking-wider">
          LTSD
        </div>
      </div>
    </div>
  );
};

export default Loading;
