
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { ProjectProgress } from './ProjectProgress';

const projects = [
  {
    id: 1,
    title: "PARK MANSION",
    subtitle: "Minami Azabu",
    image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1920&h=1080&fit=crop&crop=center",
    route: "/projects/park-mansion"
  },
  {
    id: 2,
    title: "SILENCE KAWANA",
    subtitle: "Modern Architecture",
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1920&h=1080&fit=crop&crop=center",
    route: "/projects/silence-kawana"
  },
  {
    id: 3,
    title: "PARK LE JADE",
    subtitle: "Shirokane Residence",
    image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1920&h=1080&fit=crop&crop=center",
    route: "/projects/park-le-jade"
  },
  {
    id: 4,
    title: "URBAN TOWER",
    subtitle: "Tokyo Heights",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1920&h=1080&fit=crop&crop=center",
    route: "/projects/urban-tower"
  },
  {
    id: 5,
    title: "GLASS PAVILION",
    subtitle: "Contemporary Design",
    image: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=1920&h=1080&fit=crop&crop=center",
    route: "/projects/glass-pavilion"
  },
  {
    id: 6,
    title: "MINIMAL HOUSE",
    subtitle: "Zen Architecture",
    image: "https://images.unsplash.com/photo-1448630360428-65456885c650?w=1920&h=1080&fit=crop&crop=center",
    route: "/projects/minimal-house"
  },
  {
    id: 7,
    title: "CUBE RESIDENCE",
    subtitle: "Geometric Form",
    image: "https://images.unsplash.com/photo-1494526585095-c41746248156?w=1920&h=1080&fit=crop&crop=center",
    route: "/projects/cube-residence"
  },
  {
    id: 8,
    title: "INFINITE SPACE",
    subtitle: "Fluid Design",
    image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=1920&h=1080&fit=crop&crop=center",
    route: "/projects/infinite-space"
  }
];

export const LiquidGlassCircle = () => {
  const [currentProject, setCurrentProject] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setIsLoaded(true);
    
    // Auto-reproducción cada 4 segundos
    const autoPlayInterval = setInterval(() => {
      if (!isHovering) {
        setCurrentProject(prev => (prev + 1) % projects.length);
      }
    }, 4000);

    return () => clearInterval(autoPlayInterval);
  }, [isHovering]);

  const handleProjectClick = () => {
    console.log('Navigating to:', projects[currentProject].route);
    navigate(projects[currentProject].route);
  };

  const nextProject = () => {
    setCurrentProject(prev => (prev + 1) % projects.length);
  };

  const prevProject = () => {
    setCurrentProject(prev => (prev - 1 + projects.length) % projects.length);
  };

  return (
    <div className={`min-h-screen bg-black flex items-center justify-center relative overflow-hidden cursor-none transition-all duration-1000 ${isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
      {/* Imagen de fondo */}
      <div className="absolute inset-0 transition-all duration-1000 ease-out">
        <img
          src={projects[currentProject].image}
          alt="Background"
          className="w-full h-full object-cover opacity-30 scale-110"
        />
        <div className="absolute inset-0 bg-gradient-radial from-transparent via-black/20 to-black/60"></div>
      </div>

      {/* Controles de navegación */}
      <button
        onClick={prevProject}
        className="absolute left-8 top-1/2 transform -translate-y-1/2 z-30 p-4 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-all duration-300"
      >
        <ChevronLeft className="w-6 h-6 text-white" />
      </button>

      <button
        onClick={nextProject}
        className="absolute right-8 top-1/2 transform -translate-y-1/2 z-30 p-4 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-all duration-300"
      >
        <ChevronRight className="w-6 h-6 text-white" />
      </button>

      {/* Círculo principal con liquid glass effect */}
      <div 
        className="relative z-10"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
      >
        <div className={`
          relative w-96 h-96 rounded-full transition-all duration-700 ease-out
          ${isHovering ? 'scale-110' : 'scale-100'}
        `}>
          {/* Efecto liquid glass */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/20 via-transparent to-white/10 backdrop-blur-md border border-white/30 shadow-2xl"></div>
          
          {/* Reflejo interior */}
          <div className="absolute inset-2 rounded-full bg-gradient-to-t from-transparent via-white/5 to-white/20"></div>
          
          {/* Imagen interior */}
          <div className="absolute inset-2 rounded-full overflow-hidden">
            <img
              src={projects[currentProject].image}
              alt={projects[currentProject].title}
              className="w-full h-full object-cover transition-all duration-1000"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
          </div>

          {/* Texto del proyecto */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center text-white z-10">
              <h3 className="text-lg font-light tracking-wide mb-1 drop-shadow-lg">
                {projects[currentProject].title}
              </h3>
              <p className="text-white/80 text-xs tracking-wider drop-shadow-lg">
                {projects[currentProject].subtitle}
              </p>
            </div>
          </div>

          {/* Efectos de brillo */}
          <div className="absolute -inset-2 rounded-full bg-gradient-conic from-white/20 via-transparent to-white/20 opacity-50 animate-spin-slow"></div>
        </div>

        {/* Botón clickeable */}
        <button
          onClick={handleProjectClick}
          className="absolute inset-0 rounded-full bg-transparent hover:bg-white/5 transition-all duration-300 z-20"
          aria-label={`Ver proyecto ${projects[currentProject].title}`}
        />
      </div>

      {/* Barra de progreso circular */}
      <ProjectProgress
        currentProject={currentProject}
        totalProjects={projects.length}
        onProjectChange={setCurrentProject}
      />
    </div>
  );
};
