
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";

const ProjectStage = () => {
  const [selectedProject, setSelectedProject] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const projects = [
    {
      id: 1,
      title: "PARK MANSION",
      subtitle: "Minami Azabu",
      image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=600&fit=crop"
    },
    {
      id: 2,
      title: "with Silence Kawana",
      subtitle: "",
      image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop"
    },
    {
      id: 3,
      title: "Park le JADE",
      subtitle: "SHIROKANE Residence",
      image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop"
    },
    {
      id: 4,
      title: "SEVENS VILLA",
      subtitle: "Karuizawa",
      image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop"
    },
    {
      id: 5,
      title: "HIKAWA GARDENS",
      subtitle: "",
      image: "https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4?w=800&h=600&fit=crop"
    },
    {
      id: 6,
      title: "ONE AVENUE",
      subtitle: "",
      image: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?w=800&h=600&fit=crop"
    }
  ];

  const handleProjectChange = (index: number) => {
    if (index === selectedProject) return;
    
    setIsTransitioning(true);
    setTimeout(() => {
      setSelectedProject(index);
      setIsTransitioning(false);
    }, 300);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setSelectedProject((prev) => (prev + 1) % projects.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [projects.length]);

  return (
    <div className="min-h-screen pt-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          {/* Project Display */}
          <div className="relative">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
              <img
                src={projects[selectedProject].image}
                alt={projects[selectedProject].title}
                className={`w-full h-full object-cover transition-all duration-500 ${
                  isTransitioning ? "scale-110 opacity-70" : "scale-100 opacity-100"
                }`}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              <div className="absolute bottom-8 left-8 text-white">
                <h2 className="text-3xl font-bold mb-2">
                  {projects[selectedProject].title}
                </h2>
                {projects[selectedProject].subtitle && (
                  <p className="text-lg opacity-90">
                    {projects[selectedProject].subtitle}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Project Menu */}
          <div className="space-y-4">
            <h3 className="text-xl font-medium mb-8 text-gray-600">
              Featured Projects
            </h3>
            <div className="space-y-3">
              {projects.map((project, index) => (
                <Card
                  key={project.id}
                  className={`p-4 cursor-pointer transition-all duration-300 hover:shadow-lg ${
                    selectedProject === index
                      ? "bg-gray-900 text-white shadow-lg"
                      : "bg-white hover:bg-gray-50"
                  }`}
                  onClick={() => handleProjectChange(index)}
                >
                  <div className="font-medium">
                    {project.title}
                    {project.subtitle && (
                      <div className="text-sm opacity-70 mt-1">
                        {project.subtitle}
                      </div>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectStage;
