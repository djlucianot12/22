
import { useState, useRef, useEffect } from 'react';

interface ProjectProgressProps {
  currentProject: number;
  totalProjects: number;
  onProjectChange: (project: number) => void;
}

export const ProjectProgress = ({ currentProject, totalProjects, onProjectChange }: ProjectProgressProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const circleRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number>();

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    e.preventDefault();
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging || !circleRef.current) return;

    const rect = circleRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const angle = Math.atan2(e.clientY - centerY, e.clientX - centerX);
    const degrees = (angle * 180) / Math.PI + 90;
    const normalizedDegrees = ((degrees % 360) + 360) % 360;
    
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
    
    animationRef.current = requestAnimationFrame(() => {
      setRotation(normalizedDegrees);
      
      const projectIndex = Math.floor((normalizedDegrees / 360) * totalProjects);
      const clampedIndex = Math.max(0, Math.min(totalProjects - 1, projectIndex));
      
      if (clampedIndex !== currentProject) {
        setIsTransitioning(true);
        onProjectChange(clampedIndex);
        setTimeout(() => setIsTransitioning(false), 800);
      }
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
        if (animationRef.current) {
          cancelAnimationFrame(animationRef.current);
        }
      };
    }
  }, [isDragging]);

  useEffect(() => {
    if (!isDragging) {
      const targetRotation = (currentProject / totalProjects) * 360;
      setRotation(targetRotation);
    }
  }, [currentProject, totalProjects, isDragging]);

  const progressPercentage = (rotation / 360) * 100;
  const radius = 218;
  const circumference = 2 * Math.PI * radius;
  const strokeDasharray = circumference;
  const strokeDashoffset = circumference - (progressPercentage / 100) * circumference;
  
  // Efectos de vidrio líquido mejorados
  const liquidEffect = isTransitioning ? 'animate-pulse' : '';
  const glassThickness = 20; // Grosor total del anillo de vidrio
  const innerRadius = radius - glassThickness;
  const outerRadius = radius;

  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      <div
        ref={circleRef}
        className="relative w-[440px] h-[440px] md:w-[460px] md:h-[460px] pointer-events-auto cursor-none"
        onMouseDown={handleMouseDown}
      >
        {/* Círculo base con efecto de vidrio */}
        <div className="absolute inset-0 rounded-full border border-white/8 bg-gradient-to-br from-white/2 via-transparent to-white/3 backdrop-blur-lg"></div>
        
        {/* SVG para el anillo de vidrio líquido completo */}
        <svg className="absolute inset-0 w-full h-full -rotate-90 overflow-visible">
          <defs>
            {/* Gradientes de vidrio líquido animado */}
            <radialGradient id="liquidGlassRing" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(120,200,255,0.2)" />
              <stop offset="40%" stopColor="rgba(255,255,255,0.4)">
                <animate attributeName="stop-opacity" values="0.4;0.8;0.4" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="70%" stopColor="rgba(120,200,255,0.3)">
                <animate attributeName="stop-opacity" values="0.3;0.6;0.3" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="rgba(255,255,255,0.1)" />
            </radialGradient>
            
            <radialGradient id="liquidGlassActive" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(120,200,255,0.4)" />
              <stop offset="40%" stopColor="rgba(255,255,255,0.8)">
                <animate attributeName="stop-opacity" values="0.8;0.4;0.8" dur="1s" repeatCount="indefinite" />
              </stop>
              <stop offset="70%" stopColor="rgba(120,200,255,0.6)">
                <animate attributeName="stop-opacity" values="0.6;0.9;0.6" dur="1s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="rgba(255,255,255,0.3)" />
            </radialGradient>
            
            {/* Máscaras para el progreso */}
            <mask id="progressMask">
              <rect width="100%" height="100%" fill="black" />
              <circle
                cx="50%" 
                cy="50%" 
                r={(outerRadius + innerRadius) / 2}
                fill="none"
                stroke="white"
                strokeWidth={glassThickness}
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </mask>
            
            {/* Filtros de distorsión líquida */}
            <filter id="liquidWave" x="-50%" y="-50%" width="200%" height="200%">
              <feTurbulence 
                baseFrequency="0.02" 
                numOctaves="4" 
                result="turbulence"
              >
                <animate attributeName="baseFrequency" 
                  values="0.02;0.035;0.02" 
                  dur={isTransitioning ? "0.6s" : "4s"} 
                  repeatCount="indefinite" />
              </feTurbulence>
              <feDisplacementMap 
                in="SourceGraphic" 
                in2="turbulence" 
                scale={isTransitioning ? "8" : "3"}
              />
              <feGaussianBlur stdDeviation="1" />
            </filter>
            
            <filter id="glassEffect" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="1" result="blur" />
              <feMorphology operator="dilate" radius="1" result="dilate" />
              <feComposite in="blur" in2="dilate" operator="multiply" />
            </filter>
          </defs>
          
          {/* Anillo de vidrio base (todo el grosor) */}
          <circle
            cx="50%" 
            cy="50%" 
            r={(outerRadius + innerRadius) / 2}
            fill={isTransitioning ? "url(#liquidGlassActive)" : "url(#liquidGlassRing)"}
            stroke="none"
            strokeWidth={glassThickness}
            filter="url(#liquidWave)"
            className={`transition-all ease-out ${isTransitioning ? 'duration-600' : 'duration-1000'} ${liquidEffect}`}
            style={{
              filter: isTransitioning 
                ? 'url(#liquidWave) url(#glassEffect) drop-shadow(0 0 15px rgba(120,200,255,0.8))'
                : 'url(#liquidWave) url(#glassEffect) drop-shadow(0 0 8px rgba(255,255,255,0.3))',
              strokeWidth: glassThickness
            }}
          />
          
          {/* Progreso sobre el vidrio (más sutil) */}
          <circle
            cx="50%" 
            cy="50%" 
            r={(outerRadius + innerRadius) / 2}
            fill="none"
            stroke="rgba(255,255,255,0.6)"
            strokeWidth={glassThickness}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            mask="url(#progressMask)"
            className="transition-all duration-500 ease-out"
            style={{
              filter: 'drop-shadow(0 0 10px rgba(255,255,255,0.7))'
            }}
          />
          
          {/* Reflejos de vidrio */}
          <circle
            cx="50%" 
            cy="50%" 
            r={outerRadius - 2}
            fill="none"
            stroke="rgba(255,255,255,0.3)"
            strokeWidth="1"
            className="animate-pulse"
            style={{
              animationDuration: isTransitioning ? '1s' : '3s'
            }}
          />
          <circle
            cx="50%" 
            cy="50%" 
            r={innerRadius + 2}
            fill="none"
            stroke="rgba(255,255,255,0.2)"
            strokeWidth="1"
            className="animate-pulse"
            style={{
              animationDuration: isTransitioning ? '1.2s' : '3.5s'
            }}
          />
        </svg>

        {/* Indicador de posición */}
        <div
          className={`absolute w-4 h-4 md:w-5 md:h-5 rounded-full transition-all ease-out ${
            isTransitioning ? 'duration-600 scale-125' : 'duration-300 scale-100'
          }`}
          style={{
            top: '50%',
            left: '50%',
            transform: `translate(-50%, -50%) rotate(${rotation}deg) translateY(-${outerRadius}px)`,
            background: isTransitioning 
              ? 'radial-gradient(circle, rgba(120,200,255,1) 0%, rgba(255,255,255,0.9) 70%, transparent 100%)'
              : 'radial-gradient(circle, rgba(255,255,255,0.9) 0%, rgba(120,200,255,0.7) 70%, transparent 100%)',
            boxShadow: isTransitioning
              ? '0 0 20px rgba(120,200,255,1), inset 0 2px 4px rgba(255,255,255,0.5)'
              : '0 0 12px rgba(255,255,255,0.8), inset 0 2px 4px rgba(255,255,255,0.3)',
            border: '1px solid rgba(255,255,255,0.6)',
            backdropFilter: 'blur(8px)'
          }}
        >
          <div className="absolute inset-1 bg-gradient-to-br from-white/50 via-transparent to-white/20 rounded-full"></div>
          <div className="absolute top-1 left-1 w-1 h-1 bg-white/90 rounded-full blur-sm"></div>
        </div>
      </div>
    </div>
  );
};
