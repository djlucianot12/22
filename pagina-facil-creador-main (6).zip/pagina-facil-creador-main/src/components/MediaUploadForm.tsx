
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trash2, Plus, Upload } from 'lucide-react';

interface MediaItem {
  id: string;
  url: string;
  type: 'image' | 'youtube';
}

interface MediaUploadFormProps {
  projectTitle: string;
  initialImages?: string[];
  initialVideos?: string[];
  onSave: (images: string[], videos: string[]) => void;
}

export const MediaUploadForm = ({ 
  projectTitle, 
  initialImages = [], 
  initialVideos = [], 
  onSave 
}: MediaUploadFormProps) => {
  const [images, setImages] = useState<MediaItem[]>(
    initialImages.map((url, index) => ({ id: `img-${index}`, url, type: 'image' as const }))
  );
  const [videos, setVideos] = useState<MediaItem[]>(
    initialVideos.map((url, index) => ({ id: `vid-${index}`, url, type: 'youtube' as const }))
  );

  const addImage = () => {
    const newId = `img-${Date.now()}`;
    setImages([...images, { id: newId, url: '', type: 'image' }]);
  };

  const addVideo = () => {
    const newId = `vid-${Date.now()}`;
    setVideos([...videos, { id: newId, url: '', type: 'youtube' }]);
  };

  const updateImage = (id: string, url: string) => {
    setImages(images.map(img => img.id === id ? { ...img, url } : img));
  };

  const updateVideo = (id: string, url: string) => {
    setVideos(videos.map(vid => vid.id === id ? { ...vid, url } : vid));
  };

  const removeImage = (id: string) => {
    setImages(images.filter(img => img.id !== id));
  };

  const removeVideo = (id: string) => {
    setVideos(videos.filter(vid => vid.id !== id));
  };

  const handleSave = () => {
    const imageUrls = images.filter(img => img.url.trim()).map(img => img.url);
    const videoUrls = videos.filter(vid => vid.url.trim()).map(vid => vid.url);
    onSave(imageUrls, videoUrls);
  };

  const handleImageUpload = (id: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        updateImage(id, result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-light tracking-wide mb-2">Gestionar Media</h1>
        <p className="text-gray-600">{projectTitle}</p>
      </div>

      {/* Images Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Imágenes</span>
            <Button onClick={addImage} size="sm" variant="outline">
              <Plus className="w-4 h-4 mr-1" />
              Agregar Imagen
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {images.map((image, index) => (
            <div key={image.id} className="flex items-center gap-4 p-4 border rounded-lg">
              <div className="flex-1">
                <Label htmlFor={`image-${image.id}`} className="text-sm font-medium">
                  Imagen {index + 1}
                </Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    id={`image-${image.id}`}
                    placeholder="URL de la imagen o sube un archivo"
                    value={image.url}
                    onChange={(e) => updateImage(image.id, e.target.value)}
                    className="flex-1"
                  />
                  <div className="relative">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageUpload(image.id, e)}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <Button type="button" variant="outline" size="sm">
                      <Upload className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
              {image.url && (
                <div className="w-20 h-20 rounded-lg overflow-hidden">
                  <img
                    src={image.url}
                    alt={`Preview ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <Button
                onClick={() => removeImage(image.id)}
                size="sm"
                variant="outline"
                className="text-red-600 hover:text-red-700"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
          {images.length === 0 && (
            <p className="text-gray-500 text-center py-8">
              No hay imágenes agregadas. Haz clic en "Agregar Imagen" para comenzar.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Videos Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Videos de YouTube</span>
            <Button onClick={addVideo} size="sm" variant="outline">
              <Plus className="w-4 h-4 mr-1" />
              Agregar Video
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {videos.map((video, index) => (
            <div key={video.id} className="flex items-center gap-4 p-4 border rounded-lg">
              <div className="flex-1">
                <Label htmlFor={`video-${video.id}`} className="text-sm font-medium">
                  Video {index + 1}
                </Label>
                <Input
                  id={`video-${video.id}`}
                  placeholder="URL de YouTube (ej: https://www.youtube.com/watch?v=...)"
                  value={video.url}
                  onChange={(e) => updateVideo(video.id, e.target.value)}
                  className="mt-1"
                />
              </div>
              <Button
                onClick={() => removeVideo(video.id)}
                size="sm"
                variant="outline"
                className="text-red-600 hover:text-red-700"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
          {videos.length === 0 && (
            <p className="text-gray-500 text-center py-8">
              No hay videos agregados. Haz clic en "Agregar Video" para comenzar.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-center">
        <Button onClick={handleSave} size="lg" className="px-8">
          Guardar Cambios
        </Button>
      </div>
    </div>
  );
};
