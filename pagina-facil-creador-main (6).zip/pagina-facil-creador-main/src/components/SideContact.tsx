
const SideContact = () => {
  return (
    <aside className="fixed right-8 top-1/2 transform -translate-y-1/2 z-40 hidden lg:block">
      <div className="bg-white/90 backdrop-blur-sm rounded-lg p-6 shadow-lg border border-gray-100 max-w-xs">
        <div className="space-y-6">
          <div>
            <dt className="font-medium text-gray-900 mb-2">Hello.</dt>
            <dd>
              <a
                href="mailto:ltstudiodesingbuenosaires@gmail.com"
                className="text-sm text-gray-600 hover:text-gray-900 transition-colors underline decoration-gray-300 hover:decoration-gray-900"
              >
                ltstudiodesingbuenosaires@gmail.com
              </a>
            </dd>
          </div>
          
          <div>
            <dt className="font-medium text-gray-900 mb-2">Work Together.</dt>
            <dd>
              <a
                href="mailto:ltstudiodesingbuenosaires@gmail.com"
                className="text-sm text-gray-600 hover:text-gray-900 transition-colors underline decoration-gray-300 hover:decoration-gray-900"
              >
                ltstudiodesingbuenosaires@gmail.com
              </a>
            </dd>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default SideContact;
