
import { useState, useEffect } from 'react';
import { Particles } from './Particles';
import { Progress } from '@/components/ui/progress';

interface IntroProps {
  onComplete: () => void;
  isTransitioning?: boolean;
}

const Intro = ({ onComplete, isTransitioning }: IntroProps) => {
  const [progress, setProgress] = useState(0);
  const [showText, setShowText] = useState(false);
  const [typedText, setTypedText] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const fullText = 'LT STUDIO DESIGN';

  console.log('Intro component rendered', { progress, showText, isComplete, isTransitioning });

  useEffect(() => {
    console.log('Intro useEffect starting...');
    
    // Mostrar texto después de 1 segundo y comenzar efecto de escritura
    const textTimer = setTimeout(() => {
      console.log('Starting text animation');
      setShowText(true);
      let currentIndex = 0;
      const typingInterval = setInterval(() => {
        if (currentIndex <= fullText.length) {
          setTypedText(fullText.slice(0, currentIndex));
          currentIndex++;
        } else {
          clearInterval(typingInterval);
          console.log('Text animation completed');
        }
      }, 100);
    }, 1000);
    
    // Animar barra de progreso
    const progressTimer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressTimer);
          console.log('Progress completed, finishing intro');
          // Solo llamar onComplete una vez y prevenir múltiples llamadas
          if (!isComplete) {
            setTimeout(() => {
              setIsComplete(true);
              onComplete();
            }, 500);
          }
          return 100;
        }
        return prev + 1.2;
      });
    }, 50);

    return () => {
      clearTimeout(textTimer);
      clearInterval(progressTimer);
    };
  }, [onComplete, isComplete]); // Añadir isComplete como dependencia

  return (
    <div className={`fixed inset-0 bg-black flex items-center justify-center overflow-hidden transition-all duration-1000 ease-in-out ${
      isComplete || isTransitioning ? 'opacity-0 blur-sm scale-105' : 'opacity-100 scale-100'
    }`}>
      <Particles />
      
      <div className="text-center z-10">
        <div className={`transition-all duration-1000 ${showText ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
          <h1 className="text-2xl md:text-4xl font-thin text-white mb-8 tracking-[0.15em] relative flex items-center justify-center">
            <span className="font-mono">{typedText}</span>
            <span className={`ml-1 w-0.5 h-6 md:h-8 bg-white ${showText ? 'animate-pulse' : 'opacity-0'}`}></span>
          </h1>
        </div>
        
        <div className="mt-12 w-64 md:w-80 mx-auto">
          <div className="mb-4">
            <p className="text-white/70 text-xs md:text-sm tracking-wider font-light">
              ENTRANDO AL ESTUDIO
            </p>
          </div>
          
          {/* Barra de progreso liquid glass mejorada y más fina */}
          <div className="relative h-0.5 md:h-1 bg-white/5 rounded-full overflow-hidden backdrop-blur-sm border border-white/8">
            <div 
              className="h-full bg-gradient-to-r from-white/90 via-blue-200/80 to-white/90 rounded-full relative transition-all duration-200 ease-out"
              style={{ 
                width: `${progress}%`,
                filter: 'drop-shadow(0 0 3px rgba(255,255,255,0.5)) drop-shadow(0 0 6px rgba(120,200,255,0.3))',
                boxShadow: 'inset 0 0.5px 1px rgba(255,255,255,0.2)'
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-white/15 via-transparent to-white/30 rounded-full"></div>
              <div className="absolute right-0 top-0 w-1 h-full bg-gradient-to-l from-white/50 to-transparent rounded-r-full"></div>
            </div>
          </div>
          
          <div className="mt-3 text-white/50 text-xs">
            {Math.round(progress)}%
          </div>
        </div>
      </div>
    </div>
  );
};

export default Intro;
