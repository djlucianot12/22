
import { useState, useEffect } from 'react';
import { ArrowLeft, Play, X, Edit } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { CustomCursor } from './CustomCursor';
import { YouTubeEmbed } from './YouTubeEmbed';
import { MediaUploadForm } from './MediaUploadForm';
import { PasswordProtection } from './PasswordProtection';

interface ProjectPageProps {
  title: string;
  subtitle: string;
  images: string[];
  videos: string[];
}

export const ProjectPage = ({ title, subtitle, images: initialImages, videos: initialVideos }: ProjectPageProps) => {
  const navigate = useNavigate();
  const [selectedMedia, setSelectedMedia] = useState<{ type: 'image' | 'video'; index: number } | null>(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [images, setImages] = useState(initialImages);
  const [videos, setVideos] = useState(initialVideos);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Verificar si ya tiene acceso
    const hasAccess = localStorage.getItem('editAccess') === 'granted';
    setIsAuthenticated(hasAccess);
  }, []);

  const handleBack = () => {
    navigate('/');
  };

  const openLightbox = (type: 'image' | 'video', index: number) => {
    setSelectedMedia({ type, index });
    setLightboxOpen(true);
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    setSelectedMedia(null);
  };

  const handleMediaSave = (newImages: string[], newVideos: string[]) => {
    setImages(newImages);
    setVideos(newVideos);
    setEditMode(false);
    
    // Guardar en localStorage temporalmente
    localStorage.setItem(`project_${title}_images`, JSON.stringify(newImages));
    localStorage.setItem(`project_${title}_videos`, JSON.stringify(newVideos));
  };

  const handleEditClick = () => {
    if (!isAuthenticated) {
      setEditMode(true); // Esto mostrará la protección de contraseña
    } else {
      setEditMode(true);
    }
  };

  if (editMode) {
    if (!isAuthenticated) {
      return (
        <PasswordProtection 
          onAuthenticated={() => setIsAuthenticated(true)} 
        />
      );
    }
    
    return (
      <div className="min-h-screen bg-white">
        <CustomCursor />
        <MediaUploadForm
          projectTitle={title}
          initialImages={images}
          initialVideos={videos}
          onSave={handleMediaSave}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white relative">
      <CustomCursor />
      
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-40 bg-black/80 backdrop-blur-sm">
        <div className="flex items-center justify-between p-6">
          <button
            onClick={handleBack}
            className="flex items-center gap-2 text-white/70 hover:text-white transition-colors text-sm tracking-wide"
          >
            <ArrowLeft className="w-4 h-4" />
            BACK
          </button>
          <div className="text-center">
            <h1 className="text-lg font-light tracking-[0.2em]">{title}</h1>
            <p className="text-white/60 text-xs tracking-wider mt-1">{subtitle}</p>
          </div>
          <button
            onClick={handleEditClick}
            className="flex items-center gap-2 text-white/70 hover:text-white transition-colors text-sm tracking-wide"
          >
            <Edit className="w-4 h-4" />
            EDIT
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="pt-24 pb-16">
        {/* Hero Section */}
        {images.length > 0 && (
          <div className="relative h-screen mb-16">
            <img
              src={images[0]}
              alt={`${title} - Hero`}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
            <div className="absolute bottom-16 left-16">
              <h2 className="text-5xl md:text-7xl font-thin tracking-wide mb-4">{title}</h2>
              <p className="text-2xl text-white/90 font-light tracking-wide">{subtitle}</p>
            </div>
          </div>
        )}

        {/* Images Gallery - Vertical Layout */}
        <div className="max-w-4xl mx-auto px-8 space-y-12">
          {images.slice(1).map((image, index) => (
            <div
              key={`image-${index + 1}`}
              onClick={() => openLightbox('image', index + 1)}
              className="group cursor-pointer w-full h-[80vh] overflow-hidden"
            >
              <img
                src={image}
                alt={`${title} - Image ${index + 2}`}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300"></div>
            </div>
          ))}
          
          {/* YouTube Videos */}
          {videos.map((video, index) => (
            <div
              key={`video-${index}`}
              onClick={() => openLightbox('video', index)}
              className="group cursor-pointer w-full h-[80vh] overflow-hidden relative"
            >
              <YouTubeEmbed
                url={video}
                className="w-full h-full transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/30">
                  <Play className="w-8 h-8 text-white ml-1" />
                </div>
              </div>
            </div>
          ))}

          {/* Empty State */}
          {images.length === 0 && videos.length === 0 && (
            <div className="text-center py-20">
              <p className="text-white/60 text-lg mb-4">No hay contenido disponible</p>
              <button
                onClick={handleEditClick}
                className="text-white/80 hover:text-white transition-colors text-sm tracking-wide border border-white/30 px-6 py-3 rounded-lg"
              >
                <Edit className="w-4 h-4 inline mr-2" />
                AGREGAR CONTENIDO
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && selectedMedia && (
        <div className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center">
          <button
            onClick={closeLightbox}
            className="absolute top-8 right-8 text-white/70 hover:text-white transition-colors"
          >
            <X className="w-8 h-8" />
          </button>
          
          <div className="max-w-[90vw] max-h-[90vh]">
            {selectedMedia.type === 'image' ? (
              <img
                src={images[selectedMedia.index]}
                alt={`${title} - Full size`}
                className="max-w-full max-h-full object-contain"
              />
            ) : (
              <div className="w-[80vw] h-[60vh]">
                <YouTubeEmbed
                  url={videos[selectedMedia.index]}
                  className="w-full h-full"
                />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
