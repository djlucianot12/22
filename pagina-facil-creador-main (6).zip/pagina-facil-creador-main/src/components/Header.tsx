
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentLang, setCurrentLang] = useState("En");

  const languages = [
    { code: "en", label: "En" },
    { code: "zh", label: "Cn" },
    { code: "ja", label: "Jp" }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <a href="/" className="text-2xl font-bold tracking-wider hover:opacity-70 transition-opacity">
              LTSD
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <div className="flex items-center space-x-4">
              <a href="/works" className="hover:opacity-70 transition-opacity">
                All
              </a>
              <a href="/" className="hover:opacity-70 transition-opacity">
                Focus
              </a>
            </div>
            
            <div className="flex items-center space-x-4">
              <a href="/about" className="hover:opacity-70 transition-opacity">
                About
              </a>
              <div className="flex items-center space-x-2 ml-4">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setCurrentLang(lang.label)}
                    className={`text-sm hover:opacity-70 transition-opacity ${
                      currentLang === lang.label ? "opacity-100" : "opacity-50"
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 border-t border-gray-100 pt-4">
            <div className="flex flex-col space-y-4">
              <a href="/works" className="hover:opacity-70 transition-opacity">
                All
              </a>
              <a href="/" className="hover:opacity-70 transition-opacity">
                Focus
              </a>
              <a href="/about" className="hover:opacity-70 transition-opacity">
                About
              </a>
              <div className="flex items-center space-x-4 pt-2">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setCurrentLang(lang.label)}
                    className={`text-sm hover:opacity-70 transition-opacity ${
                      currentLang === lang.label ? "opacity-100" : "opacity-50"
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
